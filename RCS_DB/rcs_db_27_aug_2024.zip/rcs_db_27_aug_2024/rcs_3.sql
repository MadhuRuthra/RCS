-- phpMyAdmin SQL Dump
-- version 5.2.1-1.el9
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 27, 2024 at 06:08 AM
-- Server version: 8.0.38
-- PHP Version: 8.2.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rcs_3`
--

-- --------------------------------------------------------

--
-- Table structure for table `compose_rcs_status_tmpl_3`
--

CREATE TABLE `compose_rcs_status_tmpl_3` (
  `comrcs_status_id` int NOT NULL,
  `compose_rcs_id` int NOT NULL,
  `variable_values` text,
  `mobile_no` varchar(13) NOT NULL,
  `media_url` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `comments` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `comrcs_status` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `comrcs_entry_date` timestamp NOT NULL,
  `response_status` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `response_message` varchar(100) DEFAULT NULL,
  `response_id` varchar(100) DEFAULT NULL,
  `corelation_id` varchar(50) NOT NULL,
  `response_date` timestamp NULL DEFAULT NULL,
  `delivery_status` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_date` timestamp NULL DEFAULT NULL,
  `read_date` timestamp NULL DEFAULT NULL,
  `read_status` char(1) DEFAULT NULL,
  `campaign_status` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `compose_rcs_status_tmpl_3`
--

INSERT INTO `compose_rcs_status_tmpl_3` (`comrcs_status_id`, `compose_rcs_id`, `variable_values`, `mobile_no`, `media_url`, `comments`, `comrcs_status`, `comrcs_entry_date`, `response_status`, `response_message`, `response_id`, `corelation_id`, `response_date`, `delivery_status`, `delivery_date`, `read_date`, `read_status`, `campaign_status`) VALUES
(5, 6, NULL, '919894606748', NULL, 'Message delivered successfully DELIVERY_SUCCESS', 'S', '2024-08-22 06:28:00', 'Y', 'DELIVERY_SUCCESS', '4448045350', '919894606748_20240822115800', '2024-08-22 06:28:01', 'Y', '2024-08-22 06:28:05', NULL, NULL, 'Y'),
(6, 6, NULL, '919572304239', NULL, 'Error Code [404], Error Text [404 NOT_FOUND - Requested entity was not found.] DELIVERY_FAILED', 'S', '2024-08-22 06:28:00', 'F', 'DELIVERY_FAILED', '4448045351', '919572304239_20240822115800', '2024-08-22 06:28:01', NULL, NULL, NULL, NULL, 'Y'),
(7, 6, NULL, '917837858672', NULL, 'Error Code [404], Error Text [404 NOT_FOUND - Requested entity was not found.] DELIVERY_FAILED', 'S', '2024-08-22 06:28:00', 'F', 'DELIVERY_FAILED', '4448045352', '917837858672_20240822115800', '2024-08-22 06:28:01', NULL, NULL, NULL, NULL, 'Y'),
(8, 6, NULL, '917652916979', NULL, 'Message delivered successfully DELIVERY_SUCCESS', 'S', '2024-08-22 06:28:00', 'Y', 'DELIVERY_SUCCESS', '4448045353', '917652916979_20240822115800', '2024-08-22 06:28:01', 'Y', '2024-08-22 06:28:03', NULL, NULL, 'Y'),
(9, 6, NULL, '919818535810', NULL, 'Error Code [404], Error Text [404 NOT_FOUND - Requested entity was not found.] DELIVERY_FAILED', 'S', '2024-08-22 06:28:00', 'F', 'DELIVERY_FAILED', '4448045354', '919818535810_20240822115800', '2024-08-22 06:28:01', NULL, NULL, NULL, NULL, 'Y'),
(10, 6, NULL, '919086814127', NULL, 'Message delivered successfully DELIVERY_SUCCESS', 'S', '2024-08-22 06:28:00', 'Y', 'DELIVERY_SUCCESS', '4448045355', '919086814127_20240822115800', '2024-08-22 06:28:01', 'Y', '2024-08-22 06:29:38', NULL, NULL, 'Y'),
(13, 8, NULL, '917652916979', NULL, 'Message delivered successfully DELIVERY_SUCCESS', 'S', '2024-08-22 13:07:58', 'Y', 'DELIVERY_SUCCESS', '4450506644', '917652916979_20240822183758', '2024-08-22 13:07:59', 'Y', '2024-08-22 13:08:02', NULL, NULL, 'Y'),
(14, 8, NULL, '917087200738', NULL, 'Message delivered successfully DELIVERY_SUCCESS', 'S', '2024-08-22 13:07:58', 'Y', 'DELIVERY_SUCCESS', '4450506645', '917087200738_20240822183758', '2024-08-22 13:07:59', 'Y', '2024-08-22 13:08:04', NULL, NULL, 'Y'),
(15, 8, NULL, '919086814127', NULL, 'Message delivered successfully DELIVERY_SUCCESS', 'S', '2024-08-22 13:07:58', 'Y', 'DELIVERY_SUCCESS', '4450506646', '919086814127_20240822183758', '2024-08-22 13:08:00', 'Y', '2024-08-22 13:08:03', NULL, NULL, 'Y'),
(16, 8, NULL, '918899327833', NULL, 'Message delivered successfully DELIVERY_SUCCESS', 'S', '2024-08-22 13:07:58', 'Y', 'DELIVERY_SUCCESS', '4450506647', '918899327833_20240822183758', '2024-08-22 13:08:00', 'Y', '2024-08-22 13:08:08', NULL, NULL, 'Y'),
(17, 8, NULL, '917837858672', NULL, 'Error Code [404], Error Text [Number is RCS disabled or Bot is not launched with the number\'s provider] DELIVERY_FAILED', 'S', '2024-08-22 13:07:58', 'F', 'DELIVERY_FAILED', '4450506648', '917837858672_20240822183758', '2024-08-22 13:07:59', NULL, NULL, NULL, NULL, 'Y'),
(18, 9, NULL, '919989000000', NULL, 'No next route found PSB_GENERIC_ERROR', 'S', '2024-08-24 07:08:54', 'F', 'PSB_GENERIC_ERROR', '4456373084', '919989000000_20240824123854', '2024-08-24 07:08:55', NULL, NULL, NULL, NULL, 'Y'),
(19, 9, NULL, '917838000000', NULL, 'No next route found PSB_GENERIC_ERROR', 'S', '2024-08-24 07:08:54', 'F', 'PSB_GENERIC_ERROR', '4456373085', '917838000000_20240824123854', '2024-08-24 07:08:55', NULL, NULL, NULL, NULL, 'Y'),
(20, 10, NULL, '917653000000', NULL, '-', 'S', '2024-08-24 07:49:51', NULL, NULL, '4456437348', '917653000000_20240824131951', NULL, NULL, NULL, NULL, NULL, 'N'),
(21, 10, NULL, '917838000000', NULL, '-', 'S', '2024-08-24 07:49:51', NULL, NULL, '4456437349', '917838000000_20240824131951', NULL, NULL, NULL, NULL, NULL, 'N'),
(22, 11, NULL, '917653000000', NULL, '-', 'S', '2024-08-24 09:46:21', NULL, NULL, '4456981022', '917653000000_20240824151621', NULL, NULL, NULL, NULL, NULL, 'N'),
(23, 11, NULL, '917838000000', NULL, '-', 'S', '2024-08-24 09:46:21', NULL, NULL, '4456981023', '917838000000_20240824151621', NULL, NULL, NULL, NULL, NULL, 'N'),
(24, 11, NULL, '917087000000', NULL, '-', 'S', '2024-08-24 09:46:21', NULL, NULL, '4456981024', '917087000000_20240824151621', NULL, NULL, NULL, NULL, NULL, 'N'),
(25, 12, NULL, '917652916979', NULL, '-', 'S', '2024-08-24 10:10:15', NULL, NULL, '4457501363', '917652916979_20240824154015', NULL, NULL, NULL, NULL, NULL, 'N'),
(26, 12, NULL, '917087200738', NULL, '-', 'S', '2024-08-24 10:10:15', NULL, NULL, '4457501364', '917087200738_20240824154015', NULL, NULL, NULL, NULL, NULL, 'N'),
(27, 12, NULL, '917837858672', NULL, '-', 'S', '2024-08-24 10:10:15', NULL, NULL, '4457501365', '917837858672_20240824154015', NULL, NULL, NULL, NULL, NULL, 'N');

-- --------------------------------------------------------

--
-- Table structure for table `compose_rcs_tmp_3`
--

CREATE TABLE `compose_rcs_tmp_3` (
  `compose_rcs_id` int NOT NULL,
  `user_id` int NOT NULL,
  `store_id` int NOT NULL,
  `rcs_config_id` int NOT NULL,
  `mobile_nos` longblob NOT NULL,
  `sender_mobile_nos` longblob NOT NULL,
  `variable_values` longblob,
  `media_values` longblob,
  `rcs_content` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `message_type` varchar(50) NOT NULL,
  `total_mobileno_count` int DEFAULT NULL,
  `content_char_count` int NOT NULL,
  `content_message_count` int NOT NULL,
  `campaign_name` varchar(30) DEFAULT NULL,
  `campaign_id` varchar(10) DEFAULT NULL,
  `mobile_no_type` varchar(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `unique_template_id` varchar(30) NOT NULL,
  `template_id` varchar(10) DEFAULT NULL,
  `rcs_status` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `rcs_entry_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `media_url` varchar(100) DEFAULT NULL,
  `reject_reason` varchar(50) DEFAULT NULL,
  `receiver_nos_path` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `compose_rcs_tmp_3`
--

INSERT INTO `compose_rcs_tmp_3` (`compose_rcs_id`, `user_id`, `store_id`, `rcs_config_id`, `mobile_nos`, `sender_mobile_nos`, `variable_values`, `media_values`, `rcs_content`, `message_type`, `total_mobileno_count`, `content_char_count`, `content_message_count`, `campaign_name`, `campaign_id`, `mobile_no_type`, `unique_template_id`, `template_id`, `rcs_status`, `rcs_entry_date`, `media_url`, `reject_reason`, `receiver_nos_path`) VALUES
(6, 3, 0, 1, 0x2d, 0x2d, 0x5b5d, 0x5b5d, 'te_pri_24821_002', 'TEXT', 6, 1, 6, 'ca_ana_235_6', 'S3E7E1IHIY', NULL, 'tmplt_pri_234_002', NULL, 'Y', '2024-08-22 06:25:35', 'NULL', NULL, '/var/www/html/rcs/uploads/compose_variables/3_csv_1724307931162.csv'),
(8, 3, 0, 1, 0x2d, 0x2d, 0x5b5d, 0x5b5d, 'te_pri_24821_002', 'TEXT', 5, 1, 5, 'ca_web_ana_235_7', 'NO5TN3BC87', NULL, 'tmplt_pri_234_002', NULL, 'Y', '2024-08-22 13:04:21', 'NULL', NULL, '/var/www/html/rcs/uploads/compose_variables/3_csv_1724331860319.csv'),
(9, 3, 0, 1, 0x2d, 0x2d, 0x5b5d, 0x5b5d, 'te_pri_24821_002', 'TEXT', 2, 1, 2, 'ca_web_ana_237_9', 'U2WPEQL2NX', NULL, 'tmplt_pri_234_002', NULL, 'Y', '2024-08-24 07:07:37', 'NULL', NULL, '/var/www/html/rcs/uploads/compose_variables/3_csv_1724483249642.csv'),
(10, 3, 0, 1, 0x2d, 0x2d, 0x5b5d, 0x5b5d, 'te_pri_24821_002', 'TEXT', 2, 1, 2, 'ca_web_ana_237_10', '8L8UR2QDXD', NULL, 'tmplt_pri_234_002', NULL, 'C', '2024-08-24 07:48:27', 'NULL', NULL, '/var/www/html/rcs/uploads/compose_variables/3_csv_1724485700750.csv'),
(11, 3, 0, 1, 0x2d, 0x2d, 0x5b5d, 0x5b5d, 'te_pri_24821_002', 'TEXT', 3, 1, 3, 'ca_web_ana_237_11', 'VU941ADL0D', NULL, 'tmplt_pri_234_002', NULL, 'C', '2024-08-24 09:45:30', 'NULL', NULL, '/var/www/html/rcs/uploads/compose_variables/3_csv_1724492727858.csv'),
(12, 3, 0, 1, 0x2d, 0x2d, 0x5b5d, 0x5b5d, 'te_pri_24821_002', 'TEXT', 3, 1, 3, 'ca_web_ana_237_12', '3IEE32U12M', NULL, 'tmplt_pri_234_002', NULL, 'C', '2024-08-24 10:09:06', 'NULL', NULL, '/var/www/html/rcs/uploads/compose_variables/3_csv_1724494144017.csv');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `compose_rcs_status_tmpl_3`
--
ALTER TABLE `compose_rcs_status_tmpl_3`
  ADD PRIMARY KEY (`comrcs_status_id`),
  ADD KEY `compose_whatsapp_id` (`compose_rcs_id`),
  ADD KEY `mobile_no` (`mobile_no`),
  ADD KEY `report_group` (`media_url`);

--
-- Indexes for table `compose_rcs_tmp_3`
--
ALTER TABLE `compose_rcs_tmp_3`
  ADD PRIMARY KEY (`compose_rcs_id`),
  ADD KEY `user_id` (`user_id`,`store_id`,`rcs_config_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `compose_rcs_status_tmpl_3`
--
ALTER TABLE `compose_rcs_status_tmpl_3`
  MODIFY `comrcs_status_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `compose_rcs_tmp_3`
--
ALTER TABLE `compose_rcs_tmp_3`
  MODIFY `compose_rcs_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
